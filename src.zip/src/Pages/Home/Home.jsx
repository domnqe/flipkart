
import { Catadiv } from "./CategoryMain/Catadiv"
import { Myslider } from "./Slider/Slider"

export const Home=()=>{
    return(
        <div>
            <Catadiv></Catadiv>
            <Myslider></Myslider>
            
        </div>
    )
}