import "../Electronics/Electronics.css"

export const Electronics=()=>{
    return(
        <div>
            <h1>elctronics page</h1>
        </div>
    )
}