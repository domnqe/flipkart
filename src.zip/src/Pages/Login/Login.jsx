import "../Login/Login.css"

export  const Login=()=>{
    return(
        <div className="loginback">
            {/* <div className="loginbody">
                <div className="leftbluelogin">
                <div><span className="loginwhitext">Login</span><p><span>Get access to your Orders, Wishlist and Recommendations</span></p></div>
                <div><img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/login_img_c4a81e.png" alt="" /></div>
                </div>
                <div className="rightinputlogin"></div>
            </div> */}
            
        </div>
    )
}