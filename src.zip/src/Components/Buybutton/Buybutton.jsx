import "../Buybutton/Buybutton.css"

export const Buybutton=({data})=>{
    return(
        <div>
            <button className="buystyle">{data}</button>
        </div>
    )
}